        <style>
        .delete_btn {
    color: white;
    font-weight: bold;
    cursor: pointer;
    position: absolute;
    top: -10px;
    right: -10px;
    border: 2px solid red;
    border-radius: 50px;
    text-align: center;
    width: 18px;
    height: 18px;
    background-color: red;
}
.images_parent_class
{
	display: inline-block;
	position:relative;
	width: 150px;
    height: 150px;
}
.images_parent_class img
{
	max-width:100%;
	width:100%;
	height:auto;
}select option, option, label,input{text-transform:capitalize !important;}
table input, table select, table textarea {    width: 360px !important;text-transform:capitalize !important;}.assoc{margin:15px 0;padding:20px 0;}

        </style>