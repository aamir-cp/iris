<?php /* Template Name: Logout */ 
wp_logout();  header('location: '.site_url());?>